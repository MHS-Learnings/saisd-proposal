# SAISD Digital Proposal Website

A free, static website for the proposed **Society of Artificial Intelligence & Skill Development (SAISD)** at The University of Lahore.

## Files
- `index.html` — page content and structure
- `styles.css` — responsive styling, visual effects and print layout
- `script.js` — navigation, scroll reveals, activity selector and presentation mode
- `assets/saisd-logo.png` — logo supplied for this project
- `assets/founder-photo.png` — founder portrait supplied for this project

## Run locally
Open `index.html` in a modern browser. No build step, package installation, API key or paid service is required. An internet connection is used only to load the optional Google Fonts; system fallbacks are included.

## Publish free with GitHub Pages
1. Create a new GitHub repository (for example, `saisd-proposal`).
2. Upload **all files and folders** from this project. Keep `index.html` at the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The URL will appear in the Pages settings.

## Functional controls
- Navigation links scroll to sections; mobile navigation opens and closes.
- Activity list buttons change the activity detail panel.
- Presentation mode supports previous/next controls and keyboard arrows; press `Esc` to exit.
- Print / Save as PDF opens the browser print dialog. Choose **Save as PDF**.
- Back to top returns to the first section.

## Important content note
The society, office-bearer roles, programme and 90-day roadmap are presented as **proposals**, not as approved or already completed activities. Final formation and activities remain subject to the University's approval, policies, calendar and available resources.
