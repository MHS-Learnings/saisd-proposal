(() => {
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const menuToggle = $('#menuToggle'), nav = $('#mainNav');
  menuToggle.addEventListener('click', () => { const open = nav.classList.toggle('open'); menuToggle.setAttribute('aria-expanded', String(open)); });
  $$('#mainNav a').forEach(a => a.addEventListener('click', () => { nav.classList.remove('open'); menuToggle.setAttribute('aria-expanded','false'); }));
  $('#navProposal').addEventListener('click', () => $('#overview').scrollIntoView({behavior:'smooth'}));
  $('#topBtn').addEventListener('click', () => window.scrollTo({top:0,behavior:'smooth'}));
  $('#printBtn').addEventListener('click', () => window.print());

  // Reveal elements only when they enter the viewport.
  const revealObserver = new IntersectionObserver(entries => entries.forEach(entry => { if(entry.isIntersecting){ entry.target.classList.add('visible'); revealObserver.unobserve(entry.target); } }), {threshold:.12});
  $$('.reveal').forEach(el => revealObserver.observe(el));

  // Reading progress indicator.
  const progress = $('#readingProgress');
  const updateProgress = () => { const max = document.documentElement.scrollHeight - innerHeight; progress.style.width = `${max > 0 ? (scrollY/max)*100 : 0}%`; };
  addEventListener('scroll', updateProgress, {passive:true}); updateProgress();

  // Activity selector updates the detail panel without leaving the page.
  const activities = [
    ['AI workshops & seminars','Interactive sessions that introduce emerging topics, explain key ideas in accessible language and invite students to ask questions.','✳'],
    ['Hands-on training sessions','Guided practice in selected tools and skills, designed for different experience levels and focused on learning through doing.','⌘'],
    ['Competitions & hackathons','Friendly challenges where student teams can apply what they know, solve defined problems and learn from one another.','⚡'],
    ['AI Innovation Summit','A proposed flagship gathering featuring talks, demonstrations and student ideas around responsible and useful applications of AI.','◇'],
    ['Inter-university collaboration','Opportunities to exchange knowledge with students and societies at other institutions, subject to coordination and approval.','⇄'],
    ['Projects & student exhibitions','A space for members to present prototypes, experiments, websites and other learning outcomes developed in teams.','▧'],
    ['Career & guest sessions','Conversations with relevant practitioners and sessions on professional skills, career pathways and responsible digital work.','↗']
  ];
  $$('.activity-item').forEach(btn => btn.addEventListener('click', () => {
    $$('.activity-item').forEach(item => item.classList.remove('active')); btn.classList.add('active');
    const item = activities[Number(btn.dataset.activity)];
    $('#activityTitle').textContent = item[0]; $('#activityText').textContent = item[1]; $('#activityArt').textContent = item[2];
    $('#activityArt').animate([{transform:'scale(.75) rotate(-12deg)',opacity:.3},{transform:'scale(1) rotate(0)',opacity:1}],{duration:420,easing:'cubic-bezier(.2,.8,.2,1)'});
    $('#activityCount').textContent = `${String(Number(btn.dataset.activity)+1).padStart(2,'0')} / 07`;
  }));

  // Optional slide-style presentation mode: each major section becomes a slide.
  const sections = [$('#home'), $('#overview'), $('#purpose'), $('#domains'), $('#activities'), $('#structure'), $('#roadmap'), $('.impact-section'), $('#founder'), $('.closing-section')].filter(Boolean);
  const hud = $('#presentationHud'); let slide = 0; let presentation = false;
  const setSlide = index => { slide = Math.max(0, Math.min(sections.length-1,index)); sections[slide].scrollIntoView({behavior:'smooth',block:'start'}); $('#slideCounter').textContent = `${String(slide+1).padStart(2,'0')} / ${String(sections.length).padStart(2,'0')}`; };
  const enterPresentation = () => { presentation = true; document.body.classList.add('presentation-mode'); hud.setAttribute('aria-hidden','false'); const current = sections.reduce((best,el,i) => Math.abs(el.getBoundingClientRect().top) < Math.abs(sections[best].getBoundingClientRect().top) ? i : best,0); setSlide(current); };
  const exitPresentation = () => { presentation = false; document.body.classList.remove('presentation-mode'); hud.setAttribute('aria-hidden','true'); };
  $('#presentationBtn').addEventListener('click', enterPresentation);
  $('#exitPresentation').addEventListener('click', exitPresentation);
  $('#prevSection').addEventListener('click', () => setSlide(slide-1));
  $('#nextSection').addEventListener('click', () => setSlide(slide+1));
  addEventListener('keydown', e => { if(!presentation) return; if(['ArrowRight','PageDown',' '].includes(e.key)){e.preventDefault();setSlide(slide+1);} if(['ArrowLeft','PageUp'].includes(e.key)){e.preventDefault();setSlide(slide-1);} if(e.key==='Escape') exitPresentation(); });
  let scrollTimer; addEventListener('scroll', () => { if(!presentation) return; clearTimeout(scrollTimer); scrollTimer=setTimeout(() => { const nearest = sections.reduce((best,el,i) => Math.abs(el.getBoundingClientRect().top) < Math.abs(sections[best].getBoundingClientRect().top) ? i : best,0); slide=nearest; $('#slideCounter').textContent=`${String(slide+1).padStart(2,'0')} / ${String(sections.length).padStart(2,'0')}`; },120); },{passive:true});
})();
